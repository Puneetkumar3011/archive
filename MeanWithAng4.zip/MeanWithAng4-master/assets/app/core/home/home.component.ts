import { Component, OnInit } from "@angular/core";
import { HeaderComponent } from "../header/header.component";

@Component({
    selector: "app-home",
    templateUrl: "./home.component.html"
})
export class HomeComponent{
    constructor() {}
    
}