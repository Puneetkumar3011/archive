import axios from "axios";

export const HYDRATE_TASK = "HYDRATE_TASK";
export const FETCH_TASK = "FETCH_TASK";

const taskBaseUrl = "http://localhost:3000/api/task";

export function getTaskList() {
  const request = axios.get(taskBaseUrl);

  return {
    type: HYDRATE_TASK,
    payload: request
  };
}

export function fetchTask(id){
  const request = axios.get(`${taskBaseUrl}/${id}`);

  return{
    type: FETCH_TASK,
    payload: request 
  }
}