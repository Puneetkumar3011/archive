import React from "react";
import {connect} from "react-redux";
import { bindActionCreators } from "redux";
import {Form, FormGroup, FormControl, Col, ControlLabel, Button, ButtonToolbar, DropdownButton, MenuItem} from "react-bootstrap";
import Moment from "moment";
import { fetchTask } from "../actions/index";

class TaskDetail extends React.Component{
    componentDidMount() {
        const { id } = this.props.match.params;
        if(!this.props.task){
            this.props.fetchTask(id);
        }
    }

    render(){
        const { task } = this.props; 
        if(!task){
            return <div>Loading...</div>;
        }

        return(
            <div>
                <FormGroup>
                    <ControlLabel>Task Detail</ControlLabel>
                    <FormControl.Static>
                        {task.description}
                    </FormControl.Static>
                </FormGroup>
                <FormGroup>
                    <ControlLabel>Date Created</ControlLabel>
                    <FormControl.Static>
                        {Moment(task.createdOn).format("LL")}
                    </FormControl.Static>
                </FormGroup>
                <FormGroup>
                    <ControlLabel>Status</ControlLabel>
                    <FormControl.Static>
                        {task.taskStatus}
                    </FormControl.Static>
                </FormGroup>
                <FormGroup>
                    <ControlLabel>Priority</ControlLabel>
                    <FormControl.Static>
                        {task.priority}
                    </FormControl.Static>
                </FormGroup>
            </div>
        );
    }
}

function mapStateToProps(state, ownProps){
    return {
        task : state.tasks[ownProps.match.params.id]
    };
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({ fetchTask }, dispatch); 
}

export default connect(mapStateToProps, mapDispatchToProps)(TaskDetail);