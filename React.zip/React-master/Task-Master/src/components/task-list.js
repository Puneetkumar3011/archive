import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { Table, Button } from "react-bootstrap";
import _ from "lodash";
import { getTaskList } from "../actions/index";

class TaskList extends React.Component{
    componentDidMount() {
        this.props.getTaskList();
    }

    onTaskClick(task){
        console.log('Task Detail: ' + JSON.stringify(task));
    }

    renderTaskList(){
        return _.map(this.props.tasks, task => {
            return (
                <tr key={String(task.id)}>
                    <td>{ task.id }</td>
                    <td>
                        <Link to={`/tasks/${task.id}`}>{task.description}</Link>
                    </td>
                </tr>
            );
        });
    }
    
    render(){
        return(
            <div>
                <Table responsive>
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Task</th>
                    </tr>
                    </thead>
                    <tbody>
                        {this.renderTaskList()}
                    </tbody>
                </Table>
            </div>
        );
    }
}

function mapStateToProps(state) {
  return { tasks: state.tasks };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({ getTaskList }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(TaskList);
