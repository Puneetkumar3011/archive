import React from "react";
import {Form, FormGroup, FormControl, Col, ControlLabel, Button, ButtonToolbar, DropdownButton, MenuItem} from "react-bootstrap";

export default class TaskInput extends React.Component{
    render(){
        return(
            <Form horizontal>
                <FormGroup>
                    <Col componentClass={ControlLabel} sm={2}>
                        Name
                    </Col>
                    <Col sm={10}>
                        <FormControl type="input" placeholder="Name" />
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} sm={2}>
                        Description
                    </Col>
                    <Col sm={10}>
                        <FormControl componentClass="textarea" placeholder="Description" />
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} sm={2}>
                        Priority
                    </Col>
                    <Col sm={10}>
                        <ButtonToolbar>
                            <DropdownButton title="Priority" id="dropdown-size-medium">
                                <MenuItem eventKey="1">Immidiate</MenuItem>
                                <MenuItem eventKey="2">High</MenuItem>
                                <MenuItem eventKey="3">Normal</MenuItem>
                            </DropdownButton>
                        </ButtonToolbar>
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col smOffset={2} sm={10}>
                        <Button type="submit">
                        Sign in
                        </Button>
                    </Col>
                </FormGroup>
            </Form>
        );
    }
}