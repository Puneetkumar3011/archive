import _ from "lodash";
import { HYDRATE_TASK, FETCH_TASK } from "../actions/index"

export default function(state = {}, action){
    switch (action.type) {
      case HYDRATE_TASK:{
        return _.mapKeys(action.payload.data.data, "id");
      }
      case FETCH_TASK:{
        return { ...state, [action.payload.data.data.id]: action.payload.data.data };
      }
      default:{
        return state;
      }
    }
}