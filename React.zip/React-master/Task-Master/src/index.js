import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { createStore, applyMiddleware } from "redux";
import ReduxPromise from "redux-promise";
import { BrowserRouter, Route, Switch, Link } from "react-router-dom";
import { Grid, Row, Col, Navbar, Nav, NavItem } from "react-bootstrap";

import App from "./components/app";
import TaskList from "./components/task-list";
import TaskInput from "./components/task-input";
import TaskDetail from "./components/task-detail";
import reducers from "./reducers"

const createStoreWithMiddleware = applyMiddleware(ReduxPromise)(createStore);

ReactDOM.render(
    <Provider store={createStoreWithMiddleware(reducers)}>
        <div>
                <Navbar inverse collapseOnSelect>
                    <Navbar.Header>
                    <Navbar.Brand>
                        <a>Task Management</a>
                    </Navbar.Brand>
                    <Navbar.Toggle />
                    </Navbar.Header>
                    <Navbar.Collapse>
                    <Nav>
                        <NavItem eventKey={1} href="#">Task</NavItem>
                        <NavItem eventKey={2} href="#">Expense</NavItem>
                    </Nav>
                    <Nav pullRight>
                        <NavItem eventKey={1} href="#">Sign up</NavItem>
                    </Nav>
                    </Navbar.Collapse>
                </Navbar>
                <Grid>
                    <Row>
                        <Col xs={2}>
                            <div className="sidebar">
                                <ul className="nav nav-sidebar">
                                    <li className="active"><a href="#">Overview <span className="sr-only">(current)</span></a></li>
                                    <li><a href="#">Task</a></li>
                                    <li><a href="#">Expense</a></li>
                                    <li><a href="#">Analytics</a></li>
                                </ul>
                            </div>
                        </Col>
                        <Col xs={8} className="row-text-align">
                            <BrowserRouter>
                                <div>
                                    <switch>
                                        <Route exact path="/tasks/input/:id" component={TaskInput} />
                                        <Route exact path="/tasks/:id" component={TaskDetail} />
                                        <Route exact path="/tasks" component={TaskList} />
                                        <Route exact path="/" component={TaskList} />
                                    </switch>
                                </div>
                            </BrowserRouter>
                        </Col>
                        <Col xs={2} >
                            &nbsp;
                        </Col>
                    </Row>
                    <div>
                        
                    </div>
                </Grid>
            </div>
    </Provider>,
    document.querySelector(".container")
);
