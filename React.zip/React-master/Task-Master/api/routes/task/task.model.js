var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    id: {type: String},
    name: {type: String, required: true},
    description: {type: String, required: true},
    priority: {type: String, required: true},
    taskStatus: {type: String, required: true},
    createdOn: {type: Date, required: true}
});

module.exports = mongoose.model('TaskMgmt', schema);