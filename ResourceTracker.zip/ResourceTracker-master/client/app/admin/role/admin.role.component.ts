import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'buss-domain',
    templateUrl: './admin.role.component.html'
})
export class AdminRoleComponent implements OnInit{
    constructor(){}
    
    ngOnInit(){

    }

}