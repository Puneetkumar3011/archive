import { Component } from '@angular/core';

@Component({
  selector: 'admin-root',
  templateUrl: './admin.component.html'
})
export class AdminComponent {
  title = 'Admin component';
}
