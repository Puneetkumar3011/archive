
export class CompanyModel{
    constructor(public id: string,
                public name: string, 
                public location: string,
                public description: string,
                public busiDomain: string,
                public logo: string
                ){}
}