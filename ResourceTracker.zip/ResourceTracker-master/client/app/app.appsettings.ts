export class AppSettings{
    public static defaultedDdlText = '--- Select ---';
}