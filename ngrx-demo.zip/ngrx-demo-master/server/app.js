var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');

var router = express.Router();
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

var appRoutes = require('./routes/app');
var companyRoutes = require('./routes/company');
var branchRoutes = require('./routes/branch');

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, PATCH, DELETE, OPTIONS');
    next();
});

app.use('/api/branch', branchRoutes);
app.use('/api/company', companyRoutes);
app.use('/', appRoutes);

app.use(function (req, res, next) {
    return res.status(400).send('Bad Request')
});

app.listen(3000)

module.exports = app;