var express = require('express');

var router = express.Router();
var companies = [];

router.get('/', function (req, res) {
    res.json(getCompanyData());
});

router.get('/:id', function (req, res) {
    var company = [];
    for(var i = 0; i < companies.length; i++){
        if(companies[i].id == req.params.id){
            company.push(companies[i]);    
        }
    }
    res.json(company);
});

router.post('/', function (req, res, next) {
    var comp = req.body;
    comp.id = Math.random();
    companies.push(comp);
    res.status(201).json({
                message: 'Saved company',
                obj: comp
            });
});

function getCompanyData(){
    var company = {
        id: Math.random(),
        name: "ABC Company",
        description: "ABC is a registered company."
    };
    company.branches = [];
    return company;
}

module.exports = router;