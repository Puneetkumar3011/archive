var express = require('express');

var router = express.Router();
var branches = [];

router.get('/', function (req, res) {
    res.json(branches);
});

router.get('/:id', function (req, res) {
    var branch = {};
    for(var i = 0; i < branches.length; i++){
        if(branches[i].id == req.params.id){
            branch = branches[i];    
        }
    }
    res.json(branch); 
});

router.post('/', function (req, res, next) {
    var branch = {};
    branch.id = Math.random();
    branch.name = req.body.name;
    branch.detail = req.body.detail;
    branches.push(branch);
    res.json(branch);
});

router.patch('/:id', function (req, res, next) {
    var branchData = null;
    console.log(req.params.id);
    for(var i = 0; i < branches.length; i++){
        if(branches[i].id == req.params.id){    
            branches[i].name = req.body.name;
            branches[i].detail = req.body.detail;
            branchData = branches[i];
        }
    }
    res.json(branchData);
});

router.delete('/:id', function(req, res, next) {
    for(var i = 0; i < branches.length; i++){
        if(branches[i].id == req.params.id){
            branchData = branches[i];
            branches.splice(i, 1);
            break;
        }
    }
    console.log(branchData);
    res.json(branchData);
    // BussDomain.findById(req.params.id, function (err, savedDomain) {
    //     if (err) {
    //         return res.status(500).json({
    //             title: 'An error occurred',
    //             error: err
    //         });
    //     }
    //     if (!savedDomain) {
    //         return res.status(500).json({
    //             title: 'No BussDomain Found!',
    //             error: {savedDomain: 'BussDomain not found'}
    //         });
    //     }
    //     savedDomain.remove(function(err, result) {
    //         if (err) {
    //             return res.status(500).json({
    //                 title: 'An error occurred',
    //                 error: err
    //             });
    //         }
    //         res.status(200).json({
    //             message: 'Deleted Domain',
    //             obj: result
    //         });
    //     });
    // });
});

module.exports = router;