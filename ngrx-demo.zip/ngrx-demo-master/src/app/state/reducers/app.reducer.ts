import { Action, combineReducers } from '@ngrx/store';
import { compose } from '@ngrx/core/compose';
import { CompanyReducer } from './company.reducer';
import { BranchReducer } from './branch.reducer';
import { AppState } from './appstate';

export default compose(combineReducers)({
    company: CompanyReducer,
    branches: BranchReducer
}); 

export type AppState = AppState;
