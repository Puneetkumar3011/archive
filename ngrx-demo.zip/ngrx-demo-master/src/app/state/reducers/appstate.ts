import { Action, combineReducers } from '@ngrx/store';
import { compose } from '@ngrx/core/compose';
import { Company } from 'app/company/company.model';
import { CompanyActions } from 'app/state/actions/company.actions';
import { BranchActions } from '../actions/branch.actions';
import { Branch } from 'app/company/branch/shared/branch.model';
import * as Immutable from 'immutable';
import { CompanyReducer } from './company.reducer';
import { BranchReducer } from './branch.reducer';

type CompanyState = Company;
type BranchState = Array<Branch>;

var appStore: Immutable.Map<string, CompanyState>;

export function setAppState(appState: any){
    appStore = Immutable.fromJS(appState);
}

export function getAppState() : AppState{
    var appState: AppState = {
        branches: [],
        company: {
            branches: [],
            description: "",
            id: "",
            name: ""
        }
    };
    if(appStore){
        appState = appStore.toJS();
    }
    return appState;
}

export interface AppState {
    company: CompanyState;
    branches: BranchState;
}; 
