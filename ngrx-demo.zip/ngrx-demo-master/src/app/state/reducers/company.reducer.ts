import { Action, combineReducers } from '@ngrx/store';
import { compose } from '@ngrx/core/compose';
import { Company } from 'app/company/company.model';
import { CompanyActions } from 'app/state/actions/company.actions';
import { AppState, setAppState, getAppState } from './appstate';

type CompanyState = Company;
const initialCompanyState: CompanyState = {
    description: "",
    id: "",
    name: "",
    branches: []
};

export function CompanyReducer (state : CompanyState = initialCompanyState, action: Action): CompanyState {
    var appState: AppState = getAppState();
    switch (action.type) {
        case CompanyActions.LOAD_COMPANY_SUCCESS: {
            var compState: CompanyState; 
            if(action.payload){
                compState = {
                    id: action.payload.id,
                    branches: action.payload.branches,
                    description: action.payload.description,
                    name: action.payload.name
                };
            }
            appState.company = compState;
            appState.branches = [];
            setAppState(appState);
            return appState.company;
        }
        case CompanyActions.GET_COMPANY_SUCCESS: {
            return appState.company;
        }
        default: {
            return initialCompanyState;
        }
    }
} 
