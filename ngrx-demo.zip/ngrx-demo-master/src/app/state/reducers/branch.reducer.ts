import { Action, combineReducers } from '@ngrx/store';
import { compose } from '@ngrx/core/compose';
import { BranchActions } from '../actions/branch.actions';
import { Branch } from 'app/company/branch/shared/branch.model';
import { AppState, setAppState, getAppState } from './appstate';

type BranchState = Array<Branch>;

const initialBranchSate : Array<Branch> = [{
    id: "",
    name: "",
    detail: ""
}];

export function BranchReducer (state : BranchState = initialBranchSate, action: Action): BranchState {
    var appState: AppState = getAppState();
    switch (action.type) {
        case BranchActions.LOAD_BRANCH_SUCCESS: {
            if(action.payload && action.payload.length > 0 && appState.company && appState.company.branches){
                appState.company.branches.length = 0;
                action.payload.forEach(branch => {
                    appState.company.branches.push(branch.id);
                });
            }
            appState.branches = action.payload;
            setAppState(appState);
            return appState.branches;
        }
        case BranchActions.ADD_BRANCH_SUCCESS: {
            if(action.payload && appState.company && appState.company.branches){
                appState.company.branches.push(action.payload.id);
                appState.branches.push(action.payload);
                setAppState(appState);
                return appState.branches;
            }
        }
        case BranchActions.MODIFY_BRANCH_SUCCESS: {
            if(action.payload && appState.branches){
                for(var i = 0; i < appState.branches.length; i++){
                    if(appState.branches[i].id === action.payload.id){
                        appState.branches[i] = action.payload;
                    }
                }
                setAppState(appState);
                return appState.branches;
            }
        }
        case BranchActions.DELETE_BRANCH_SUCCESS: {
            if(action.payload && appState.branches){
                for(var i = 0; i < appState.branches.length; i++){
                    if(appState.branches[i].id === action.payload.id){
                        appState.branches.splice(i,1);
                        appState.company.branches.splice(appState.company.branches.indexOf(action.payload.id), 1);
                        break;
                    }
                }
                setAppState(appState);
                return appState.branches;
            }
        }
        case BranchActions.GET_BRANCH_SUCCESS: {
            return getAppState().branches;
        }
        default: {
            return initialBranchSate;
        }
    }
}
