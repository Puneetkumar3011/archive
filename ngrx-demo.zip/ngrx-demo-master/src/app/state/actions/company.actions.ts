import {Injectable} from '@angular/core';
import {Action} from '@ngrx/store';
import {Company} from 'app/company/company.model';

@Injectable()
export class CompanyActions {
    /* static variables */
    static GET_COMPANY = 'GET_COMPANY';
    static GET_COMPANY_SUCCESS = 'GET_COMPANY_SUCCESS';
    static LOAD_COMPANY = 'LOAD_COMPANY';
    static LOAD_COMPANY_SUCCESS = 'LOAD_COMPANY_SUCCESS'; 
    static RESET_BLANK_COMPANY = 'RESET_BLANK_COMPANY';    

    /* company actions */
    getLoadCompany(): Action {
        return {
            type: CompanyActions.LOAD_COMPANY
        };
    }

    loadCompanySuccess(company): Action {
        return {
            type: CompanyActions.LOAD_COMPANY_SUCCESS,
            payload: company
        };
    }

    getCompany(): Action {
        return {
            type: CompanyActions.GET_COMPANY
        };
    }

    getCompanySuccess(company): Action {
        return {
            type: CompanyActions.GET_COMPANY_SUCCESS,
            payload: company
        };
    }

    resetBlankCompany(): Action {
        return {
            type: CompanyActions.RESET_BLANK_COMPANY
        };
    }

}