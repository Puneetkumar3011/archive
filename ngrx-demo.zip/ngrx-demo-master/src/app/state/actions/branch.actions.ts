import {Injectable} from '@angular/core';
import {Action} from '@ngrx/store';
import {Company} from 'app/company/company.model';

@Injectable()
export class BranchActions {
    /* static variables */
    static LOAD_BRANCH = 'LOAD_BRANCH';    
    static LOAD_BRANCH_SUCCESS = 'LOAD_BRANCH_SUCCESS';    
    static GET_BRANCH_SUCCESS = 'GET_BRANCH_SUCCESS';
    static GET_BRANCH = 'GET_BRANCH';
    static ADD_BRANCH = 'ADD_BRANCH';    
    static ADD_BRANCH_SUCCESS = 'ADD_BRANCH_SUCCESS';
    static MODIFY_BRANCH = 'MODIFY_BRANCH';    
    static MODIFY_BRANCH_SUCCESS = 'MODIFY_BRANCH_SUCCESS';
    static DELETE_BRANCH = 'DELETE_BRANCH';    
    static DELETE_BRANCH_SUCCESS = 'DELETE_BRANCH_SUCCESS';

    /* branch actions */
    loadBranch(): Action {
        return {
            type: BranchActions.LOAD_BRANCH
        };
    }

    loadBranchSuccess(branches): Action {
        return {
            type: BranchActions.LOAD_BRANCH_SUCCESS,
            payload: branches
        };
    }

    getBranch(): Action {
        return {
            type: BranchActions.GET_BRANCH
        };
    }

    getBranchSuccess(): Action {
        return {
            type: BranchActions.GET_BRANCH_SUCCESS
        };
    }

    addBranch(branch): Action {
        return {
            type: BranchActions.ADD_BRANCH,
            payload: branch
        };
    }

    addBranchSuccess(branch): Action {
        return {
            type: BranchActions.ADD_BRANCH_SUCCESS,
            payload: branch
        };
    }

    modifyBranch(branch): Action {
        return {
            type: BranchActions.MODIFY_BRANCH,
            payload: branch
        };
    }

    modifyBranchSuccess(branch): Action {
        return {
            type: BranchActions.MODIFY_BRANCH_SUCCESS,
            payload: branch
        };
    }

    deleteBranch(branch): Action {
        return {
            type: BranchActions.DELETE_BRANCH,
            payload: branch
        };
    }

    deleteBranchSuccess(branch): Action {
        return {
            type: BranchActions.DELETE_BRANCH_SUCCESS,
            payload: branch
        };
    }
}