import {Injectable} from '@angular/core';
import {Effect, Actions} from '@ngrx/effects';
import 'rxjs/add/operator/switchMap';

import { AppState } from '../reducers/app.reducer';
import { BranchActions } from '../actions/branch.actions';
import { CompanyService } from '../../company/company.service';

@Injectable()
export class BranchEffects {
    constructor (
        private update$: Actions,
        private branchActions: BranchActions,
        private svcCompany: CompanyService,
    ) {}

    @Effect() loadBranch$ = this.update$
        .ofType(BranchActions.LOAD_BRANCH)
        .switchMap(() => { 
            return this.svcCompany.loadBranches();
        }) 
        .map(branches => { 
            return this.branchActions.loadBranchSuccess(branches);
        });

    @Effect() getBranch$ = this.update$
        .ofType(BranchActions.GET_BRANCH)
        .map(branches => { 
            return this.branchActions.getBranchSuccess();
        });

    @Effect() addBranch$ = this.update$
        .ofType(BranchActions.ADD_BRANCH)
        .map(action => action.payload)
        .switchMap(branch => this.svcCompany.addBranch(branch))
        .map(branch => this.branchActions.addBranchSuccess(branch));

    @Effect() updateBranch$ = this.update$
        .ofType(BranchActions.MODIFY_BRANCH)
        .map(action => action.payload)
        .switchMap(branch => this.svcCompany.modifyBranch(branch))
        .map(branch => this.branchActions.modifyBranchSuccess(branch));

    @Effect() deleteBranch$ = this.update$
        .ofType(BranchActions.DELETE_BRANCH)
        .map(action => action.payload)
        .switchMap(branch => this.svcCompany.deleteBranch(branch))
        .map(branch => this.branchActions.deleteBranchSuccess(branch));
    
}