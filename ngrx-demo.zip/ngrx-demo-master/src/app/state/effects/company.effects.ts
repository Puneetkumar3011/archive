import {Injectable} from '@angular/core';
import {Effect, Actions} from '@ngrx/effects';
import 'rxjs/add/operator/switchMap';

import { AppState } from '../reducers/app.reducer';
import { CompanyActions } from '../actions/company.actions';
import { CompanyService } from '../../company/company.service';

@Injectable()
export class CompanyEffects {
    constructor (
        private update$: Actions,
        private companyActions: CompanyActions,
        private svcCompany: CompanyService,
    ) {}

    @Effect() loadCompany$ = this.update$
        .ofType(CompanyActions.LOAD_COMPANY)
        .switchMap(() => { 
            return this.svcCompany.getCompany();
        }) 
        .map(company => { 
            return this.companyActions.loadCompanySuccess(company);
        });

    @Effect() getCompany$ = this.update$
        .ofType(CompanyActions.GET_COMPANY)
        .map(company => { 
            return this.companyActions.getCompanySuccess(company);
        });
}