import { BranchEffects } from './branch.effects';
import { CompanyEffects } from './company.effects';

export {
    BranchEffects,
    CompanyEffects
};

export default [
    BranchEffects,
    CompanyEffects
];