import {Component} from '@angular/core';
import {Store} from '@ngrx/store';

@Component({
    selector: 'app-dashboard',
    templateUrl: 'dashboard.component.html'
})

export class DashboardComponent {
    title = 'Company Dashboard';
}