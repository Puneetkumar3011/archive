import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {DashboardComponent} from "./dashboard/dashboard.component";
import {CompanyComponent} from './company/company.component';
import {CompanyRoutes} from './company/routes';

const routes: Routes = [
    {path: '', redirectTo: '/dashboard', pathMatch: 'full'},
    {path: 'dashboard', component: DashboardComponent },
    {path: 'company', component: CompanyComponent, children: CompanyRoutes }
];

//export default routes;
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);