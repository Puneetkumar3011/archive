import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {DashboardComponent} from "../dashboard/dashboard.component";
import {OverviewComponent} from './overview/overview.component';
import { BranchComponent } from './branch/branch.component'
import { BranchRoutes } from './branch/shared/branch.routing';

export const CompanyRoutes: Routes = [
    {path: '', redirectTo: 'overview', pathMatch: 'full'},
    {path: 'overview', component: OverviewComponent },
    {path: 'branch', component: BranchComponent, children: BranchRoutes }
];
