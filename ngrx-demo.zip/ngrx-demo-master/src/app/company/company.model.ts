import {Branch} from './branch/shared/branch.model';

export interface Company {
    id: string,
    description: string,
    name: string,
    branches: Array<string>
}
