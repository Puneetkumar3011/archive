import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Store} from '@ngrx/store';
import {Router, ActivatedRoute, Params} from '@angular/router';

import {AppState} from '../state/reducers/app.reducer';
import {CompanyActions} from '../state/actions/company.actions';
import {Company} from './company.model';

@Component({
    selector: 'ngrx-company',
    templateUrl: 'company.component.html'
})
export class CompanyComponent implements OnInit {
    ngOnInit() {
        console.log("ngOnInit: CompanyComponent");
    }
     
}