import { Component, OnInit, Input, ChangeDetectionStrategy, EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store'; 
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';

import { AppState } from '../../../state/reducers/app.reducer';
import { BranchActions } from '../../../state/actions/branch.actions';
import { BranchService } from '../shared/branch.service';
import { Branch } from './../shared/branch.model';

@Component({
    selector: 'branch-input',
    templateUrl: 'branch-input.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class BranchInputComponent implements OnInit {
    branchForm: FormGroup; 
    @Output() onBranchUpdate = new EventEmitter<string>();
    @Input() reqType: string;

    constructor(private store: Store<AppState>, private branchActions: BranchActions, 
    private branchSvc: BranchService, private router: Router){ }

    ngOnInit() {
        this.initiateForm();
    }

    initiateForm(){
        this.branchForm = new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null, Validators.required),
          detail: new FormControl(null, Validators.required)
      });
      if(this.branchSvc.branchToEdit){
            this.branchForm = new FormGroup({
                id: new FormControl(this.branchSvc.branchToEdit.id),
                name: new FormControl(this.branchSvc.branchToEdit.name, Validators.required),
                detail: new FormControl(this.branchSvc.branchToEdit.detail, Validators.required)
            });
        } else{
            this.branchForm.reset();                        
        }
    }

    deleteBranch(): void{
        var branch: Branch = this.branchForm.value;
        this.store.dispatch(this.branchActions.deleteBranch(branch));
        this.router.navigateByUrl('/company/branch/list');
    }

    onSubmit(){
        var branch: Branch = this.branchForm.value;
        if(branch.id){
            this.store.dispatch(this.branchActions.modifyBranch(branch));
        } else{
            this.store.dispatch(this.branchActions.addBranch(branch));
        }
        this.router.navigateByUrl('/company/branch/list');
    }

    backToList(){
        this.router.navigateByUrl('/company/branch/list');
    }
     
}