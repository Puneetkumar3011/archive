import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store'; 
import { AppState } from '../../state/reducers/app.reducer';
import { BranchActions } from '../../state/actions/branch.actions';
import { Branch } from './shared/branch.model';

@Component({
    selector: 'company-overview',
    templateUrl: 'branch.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class BranchComponent implements OnInit {
    pageMode: string = 'LIST';
    branchToEdit: Branch;
    constructor(private store: Store<AppState>, private branchActions: BranchActions){
        
    }

    ngOnInit() {
        console.log("ngOnInit: BranchComponent");
        this.store.dispatch(this.branchActions.loadBranch()); 
    }

    onBranchUpdate(mode: string) : void{
        this.pageMode = mode;
    }

    onEditBranchClick(branch: Branch){
        this.pageMode='EDIT';
        this.branchToEdit = branch;
    }
}