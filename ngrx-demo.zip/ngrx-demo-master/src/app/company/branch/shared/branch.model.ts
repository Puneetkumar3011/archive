export interface Branch {
    id: string,
    name: string,
    detail: string
}