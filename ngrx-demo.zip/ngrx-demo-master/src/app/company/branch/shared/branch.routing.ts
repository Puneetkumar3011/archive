import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import { BranchInputComponent } from "../branch-input/branch-input.component";
import { BranchListComponent } from '../branch-list/branch-list.component';

export const BranchRoutes: Routes = [
    {path: '', redirectTo: 'list', pathMatch: 'full'},
    {path: 'list', component: BranchListComponent },
    {path: 'input', component: BranchInputComponent }
];
