import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Branch } from '../shared/branch.model';

@Injectable()
export class BranchService {
    constructor (private http: Http) {}
    public branchToEdit: Branch;
    
}