import {Component, OnInit, ChangeDetectionStrategy, EventEmitter, Output} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Store} from '@ngrx/store';
import {Router, ActivatedRoute, Params} from '@angular/router';

import { AppState } from '../../../state/reducers/app.reducer';
import { BranchActions } from '../../../state/actions/branch.actions';
import {CompanyActions} from '../../../state/actions/company.actions';
import { Company } from './../../company.model';
import { Branch } from './../../branch/shared/branch.model';
import { BranchService } from '../shared/branch.service';

@Component({
    selector: 'branch-list',
    templateUrl: 'branch-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class BranchListComponent implements OnInit {
    branchCount:number = 0;
    branch$: Observable<Array<Branch>>;
    //@Output() onEditBranchClick = new EventEmitter<Branch>();

    constructor(private store: Store<AppState>, private branchActions: BranchActions, private router: Router, 
    private route: ActivatedRoute, private branchSvc: BranchService){
        this.branch$ = store.select(x => {
            return x.branches;
        });
    }

    ngOnInit() {
        this.store.dispatch(this.branchActions.getBranch());
    }

    editBranch(branch: Branch){
        this.branchSvc.branchToEdit = branch;
        this.router.navigateByUrl('/company/branch/input');
    }

    addBranch(){
        this.branchSvc.branchToEdit = null;
        this.router.navigateByUrl('/company/branch/input');
    }
     
}