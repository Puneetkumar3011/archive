import {Component, OnInit, ChangeDetectionStrategy} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Store} from '@ngrx/store';
import {Router, ActivatedRoute, Params} from '@angular/router';

import { AppState } from '../../../state/reducers/app.reducer';
import { BranchActions } from '../../../state/actions/branch.actions';
import {CompanyActions} from '../../../state/actions/company.actions';
import { Company } from './../../company.model';
import { Branch } from './../../branch/shared/branch.model';

@Component({
    selector: 'branch-count',
    templateUrl: 'branch.count.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class BranchCountComponent implements OnInit {
    branch$: Observable<Array<Branch>>;
    branchCount:number = 0;
    constructor(private store: Store<AppState>, private branchActions: BranchActions){
        this.branch$ = store.select(x => {
            return x.branches;
        });

        this.branch$.subscribe((branch : Array<Branch>) => {
            let count = 0;
            if(branch && branch.length > 0){
                branch.forEach(function(b) {
                    if(b && b.name){
                        count = count + 1; 
                    }
                });
            }
            this.branchCount = count;
        });
    }
    ngOnInit() {
        this.store.dispatch(this.branchActions.getBranch());
    }
     
}