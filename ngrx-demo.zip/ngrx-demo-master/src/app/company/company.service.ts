import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Company } from './company.model';
import { Branch } from './branch/shared/branch.model';

@Injectable()
export class CompanyService {
    constructor (private http: Http) {}
    
    headers = new Headers(
        {'Content-Type': 'application/json',
            'Accept': 'application/json'
    });

    getCompany(): Observable<Company> {
        return this.http.get('http://localhost:3000/api/company/')
        .map(res => {
            return res.json();
        });
    }

    loadBranches(): Observable<Company[]> {
        return this.http.get('http://localhost:3000/api/branch/')
        .map(function(res){ 
            return res.json();
        });
    }

    addBranch(branch: Branch): Observable<Branch>{
        return this.http.post('http://localhost:3000/api/branch/', JSON.stringify(branch), {headers: this.headers})
            .map(res => { 
                return res.json()
            });
    }

    modifyBranch(branch: Branch): Observable<Branch>{
        return this.http.patch('http://localhost:3000/api/branch/' + + branch.id, JSON.stringify(branch), {headers: this.headers})
            .map(res => { 
                return res.json()
            });
    }

    deleteBranch(branch: Branch): Observable<Branch>{
        return this.http.delete('http://localhost:3000/api/branch/' + + branch.id, {headers: this.headers})
            .map(res => { 
                return res.json()
            });
    }
}