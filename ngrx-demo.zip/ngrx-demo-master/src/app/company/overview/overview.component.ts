import {Component, OnInit, Input, ChangeDetectionStrategy} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Store} from '@ngrx/store';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {AppState} from '../../state/reducers/app.reducer';
import {CompanyActions} from '../../state/actions/company.actions';
import {Company} from '../company.model';

@Component({
    selector: 'company-overview',
    templateUrl: 'overview.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OverviewComponent implements OnInit {
    company$: Observable<Company>;
    company: Company;
    constructor(private store: Store<AppState>,
            private companyActions: CompanyActions,
            private router: Router,
            private route: ActivatedRoute) {
                this.company$ = store.select(x => {
                    return x.company;
                });

                this.company$.subscribe(data => {
                    return this.company = data;
                })
            }

    ngOnInit() {
        this.store.dispatch(this.companyActions.getCompany());
    }
     
}