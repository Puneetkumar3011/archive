import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {Store, StoreModule} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';

import reducer from './state/reducers/app.reducer';
import { CompanyEffects, BranchEffects } from './state/effects';

import { AppComponent } from './app.component';
import { CompanyActions } from './state/actions/company.actions';
import { BranchActions } from './state/actions/branch.actions';
import { CompanyService } from './company/company.service';
import { BranchService } from './company/branch/shared/branch.service';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { CompanyComponent } from './company/company.component';
import { OverviewComponent } from './company/overview/overview.component';
import { BranchComponent } from './company/branch/branch.component';
import { BranchCountComponent } from './company/branch/branch-count/branch.count.component';
import { BranchListComponent } from './company/branch/branch-list/branch-list.component';
import { BranchInputComponent } from './company/branch/branch-input/branch-input.component';
import { routing } from './routes';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    CompanyComponent,
    OverviewComponent,
    BranchComponent,
    BranchCountComponent,
    BranchListComponent,
    BranchInputComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    routing,
    StoreModule.provideStore(reducer),
    EffectsModule.run(CompanyEffects),
    EffectsModule.run(BranchEffects)
  ],
  providers: [CompanyActions, BranchActions, CompanyService, BranchService], 
  bootstrap: [AppComponent]
})
export class AppModule { }
