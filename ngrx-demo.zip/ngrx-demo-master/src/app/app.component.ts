import {Component, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs/Observable';
import {AppState} from './state/reducers/app.reducer';
import {getAppState} from './state/reducers/appstate';
import {CompanyActions} from './state/actions/company.actions';

@Component({
    selector: 'app-root',
    template: `
        <div [hidden]="company$ | async">
            <span (click)="checkStoreState()" style="cursor:pointer;color:blue;text-decoration:underline">View State In Console</span>
        </div>
        <router-outlet></router-outlet>
    `
})
export class AppComponent implements OnInit {
    title = 'Companies';
    company$: Observable<any>;
    constructor(
        private store: Store<AppState>,
        private companyActions: CompanyActions
    ) {}

    ngOnInit() {
        this.store.dispatch(this.companyActions.getLoadCompany());
    }

    checkStoreState(){
        // this.company$ = this.store.select(s => { 
        //     return console.log(s.company)
        // });
        console.log('Current State: \n');
        console.log(getAppState());
    }

}