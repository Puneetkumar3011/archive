# NgrxStoreDemo

This project is build to demonstrate state management in complex Angular-2 application. 
It is using ngrx framework (ngrx Effect and Actions) for state management.
Project is using Immutable JS for immutability, Node JS for API CRUD operations, and 
ChangeDetectionStrategy to demonstrate app performance.

## Development server
    1. Go to root directory (ngrx-demo) and Run `ng serve` for UI application. Navigate to `http://localhost:4200/`
    2. Go to root/server directive (ngrx-demo\server) and Run `nodemon app,js` for Node API 

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Deploying to GitHub Pages

Run `ng github-pages:deploy` to deploy to GitHub Pages.

